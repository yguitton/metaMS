### R code from vignette source 'runGC.Rnw'

###################################################
### code chunk number 1: runGC.Rnw:110-114
###################################################
library(metaMS)
data(FEMsettings)
GCsettings <- FEMsettings[[3]]
GCsettings[1:3]


###################################################
### code chunk number 2: runGC.Rnw:137-142 (eval = FALSE)
###################################################
## library(metaMSdata)
## cdfdir <- system.file("CDF_GC", package = "metaMSdata")
## cdffiles <- list.files(cdfdir, pattern = "cdf",
##                        full.names = TRUE, ignore.case = TRUE)
## result <- runGC(files = cdffiles, settings = GCsettings, DB = DB)


###################################################
### code chunk number 3: runGC.Rnw:146-147 (eval = FALSE)
###################################################
## result <- runGC(xset = GCset, settings = GCsettings, DB = DB)


###################################################
### code chunk number 4: runGC.Rnw:162-163
###################################################
data("GCresults")


###################################################
### code chunk number 5: runGC.Rnw:174-176 (eval = FALSE)
###################################################
## GCset <- peakDetection(cdffiles, settings = GCsettings$PeakPicking, 
##                         convert2list = TRUE)


###################################################
### code chunk number 6: runGC.Rnw:210-212 (eval = FALSE)
###################################################
## allSamples <- lapply(GCset, runCAMERA, chrom = GCsettings$chrom, 
##                      settings = GCsettings$CAMERA)


###################################################
### code chunk number 7: runGC.Rnw:223-225 (eval = FALSE)
###################################################
## allSamples.msp <- lapply(allSamples, to.msp, file = NULL, 
##                          settings = GCsettings$DBconstruction)


###################################################
### code chunk number 8: runGC.Rnw:227-229
###################################################
sapply(allSamples.msp, length)
allSamples.msp[[1]][[26]]


###################################################
### code chunk number 9: runGC.Rnw:242-243
###################################################
plotPseudoSpectrum(allSamples.msp[[1]][[26]])


###################################################
### code chunk number 10: runGC.Rnw:260-266
###################################################
data(threeStdsDB)        ## provides DB
DB.treated <- treat.DB(DB)
allSam.matches <- matchSamples2DB(allSamples.msp, DB = DB.treated, 
                                  settings = GCsettings$match2DB, 
                                  quick = FALSE)
allSam.matches


###################################################
### code chunk number 11: runGC.Rnw:282-284
###################################################
matchExpSpec(allSamples.msp[[1]][[4]], DB.treated, 
             DB.treated = TRUE, plotIt = TRUE)


###################################################
### code chunk number 12: runGC.Rnw:323-331
###################################################
allSamples.msp.scaled <- lapply(allSamples.msp, treat.DB, 
                                isMSP = FALSE)
allSam.matches <- 
    matchSamples2Samples(allSamples.msp.scaled, 
                         allSamples.msp, 
                         annotations = allSam.matches$annotations, 
                         settings = GCsettings$betweenSamples)
names(allSam.matches)


###################################################
### code chunk number 13: runGC.Rnw:341-342
###################################################
allSam.matches$annotations[[1]]


###################################################
### code chunk number 14: runGC.Rnw:355-358
###################################################
features.df <- getFeatureInfo(stdDB = DB, allMatches = allSam.matches, 
                              sampleList = allSamples.msp)
features.df[, c(1:3, 12:15)]


###################################################
### code chunk number 15: runGC.Rnw:380-385
###################################################
PseudoSpectra <- constructExpPseudoSpectra(allMatches = allSam.matches, 
                                           standardsDB = DB)
ann.df <- getAnnotationMat(exp.msp = allSamples.msp, pspectra = PseudoSpectra, 
                           allMatches = allSam.matches)
ann.df


###################################################
### code chunk number 16: runGC.Rnw:391-395
###################################################
ann.df2 <- sweep(ann.df, 1, sapply(PseudoSpectra, 
                                   function(x) max(x$pspectrum[, 2])), 
                 FUN = "*")
ann.df2


###################################################
### code chunk number 17: runGC.Rnw:419-427
###################################################
library(metaMSdata)
stddir <- system.file("CDF_GC", package = "metaMSdata")
input.file <- list.files(stddir, pattern = "csv", full.names = TRUE)
threeStdsInfo <- readStdInfo(input.file, stddir, sep = ";", dec = ",")
threeStdsInfo[,"stdFile"] <- paste(stddir, 
                                   "GW_130820_12.cdf",
                                   sep = "/")
threeStdsInfo[,c(1:4, 8)]


###################################################
### code chunk number 18: runGC.Rnw:442-445
###################################################
data(FEMsettings)
data(threeStdsNIST)  ## provides smallDB
DB <- createSTDdbGC(threeStdsInfo, GCsettings, extDB = smallDB)


###################################################
### code chunk number 19: runGC.Rnw:454-455
###################################################
names(DB[[1]])


