### R code from vignette source 'runLC.Rnw'

###################################################
### code chunk number 1: runLC.Rnw:54-58
###################################################
library(metaMSdata)
cdfpath <- system.file("CDF_LC", package = "metaMSdata")
files <- list.files(cdfpath, "CDF", full.names=TRUE)
files


###################################################
### code chunk number 2: runLC.Rnw:63-65
###################################################
library(metaMS)
data(exptable)


###################################################
### code chunk number 3: runLC.Rnw:68-69
###################################################
head(exptable)


###################################################
### code chunk number 4: runLC.Rnw:86-91
###################################################
exptable$stdFile <- sapply(exptable$stdFile, function(x){
    out <- files[grep(x,files)]
  })

exptable$stdFile


###################################################
### code chunk number 5: runLC.Rnw:96-98
###################################################
data(FEMsettings)
FEMsettings$Synapt.QTOF.RP$PeakPicking


###################################################
### code chunk number 6: runLC.Rnw:102-103
###################################################
FEMsettings$Synapt.QTOF.RP$DBconstruction


###################################################
### code chunk number 7: runLC.Rnw:110-111
###################################################
exptable$compound


###################################################
### code chunk number 8: runLC.Rnw:114-120
###################################################
library(metaMSdata)
cdfpath <- system.file("CDF_LC", package = "metaMSdata")
files <- list.files(cdfpath, "CDF", full.names=TRUE)
exptable$stdFile <- sapply(exptable$stdFile,
            function(x)
            files[grep(x,files)])


###################################################
### code chunk number 9: runLC.Rnw:124-125
###################################################
FEMsettings$Synapt.QTOF.RP$DBconstruction$minfeat  <- 2


###################################################
### code chunk number 10: runLC.Rnw:129-133
###################################################
LCDBtest <- createSTDdbLC(stdInfo=exptable, 
                          settings = FEMsettings$Synapt.QTOF.RP,
                          polarity = "positive",
                          Ithr = 20)


###################################################
### code chunk number 11: runLC.Rnw:137-138
###################################################
names(LCDBtest)


###################################################
### code chunk number 12: runLC.Rnw:141-142
###################################################
head(LCDBtest$Reftable)


###################################################
### code chunk number 13: runLC.Rnw:145-146
###################################################
names(LCDBtest$Info)


###################################################
### code chunk number 14: runLC.Rnw:149-150
###################################################
head(LCDBtest$DB)


###################################################
### code chunk number 15: runLC.Rnw:155-156
###################################################
table(LCDBtest$DB$compound)


###################################################
### code chunk number 16: runLC.Rnw:173-175
###################################################
results  <- runLC(files, settings = FEMsettings$Synapt.QTOF.RP, 
                  DB = LCDBtest$DB)


###################################################
### code chunk number 17: runLC.Rnw:179-180
###################################################
head(results$Annotation$annotation.table)


###################################################
### code chunk number 18: runLC.Rnw:194-196
###################################################
results$Annotation$compounds
results$Annotation$ChemSpiderIDs


###################################################
### code chunk number 19: runLC.Rnw:200-201
###################################################
results$Annotation$multiple.annotations


###################################################
### code chunk number 20: runLC.Rnw:205-206
###################################################
results$Annotation$ann.features


###################################################
### code chunk number 21: runLC.Rnw:211-212
###################################################
head(results$PeakTable)


