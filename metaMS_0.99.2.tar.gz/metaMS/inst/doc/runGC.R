### R code from vignette source 'runGC.Rnw'

###################################################
### code chunk number 1: runGC.Rnw:110-114
###################################################
library(metaMS)
data(FEMsettings)
TSQXLS.GC
metaSetting(TSQXLS.GC, "PeakPicking")


###################################################
### code chunk number 2: runGC.Rnw:137-142 (eval = FALSE)
###################################################
## library(metaMSdata)
## cdfdir <- system.file("CDF_GC", package = "metaMSdata")
## cdffiles <- list.files(cdfdir, pattern = "cdf",
##                        full.names = TRUE, ignore.case = TRUE)
## result <- runGC(files = cdffiles, settings = TSQXLS.GC, DB = DB)


###################################################
### code chunk number 3: runGC.Rnw:146-147 (eval = FALSE)
###################################################
## result <- runGC(xset = GCset, settings = TSQXLS.GC, DB = DB)


###################################################
### code chunk number 4: runGC.Rnw:162-163
###################################################
data("GCresults")


###################################################
### code chunk number 5: runGC.Rnw:174-177 (eval = FALSE)
###################################################
## GCset <- peakDetection(cdffiles, 
##                        settings = metaSettigns(TSQXLS.GC, "PeakPicking"), 
##                        convert2list = TRUE)


###################################################
### code chunk number 6: runGC.Rnw:211-213 (eval = FALSE)
###################################################
## allSamples <- lapply(GCset, runCAMERA, chrom = "GC", 
##                      settings = metaSetting(TSQXLS.GC, "CAMERA"))


###################################################
### code chunk number 7: runGC.Rnw:224-226 (eval = FALSE)
###################################################
## allSamples.msp <- lapply(allSamples, to.msp, file = NULL, 
##                          settings = metaSetting(TSQXLS.GC, "DBconstruction"))


###################################################
### code chunk number 8: runGC.Rnw:228-230
###################################################
sapply(allSamples.msp, length)
allSamples.msp[[1]][[26]]


###################################################
### code chunk number 9: runGC.Rnw:243-244
###################################################
plotPseudoSpectrum(allSamples.msp[[1]][[26]])


###################################################
### code chunk number 10: runGC.Rnw:261-268
###################################################
data(threeStdsDB)        ## provides DB
DB.treated <- treat.DB(DB)
allSam.matches <- 
    matchSamples2DB(allSamples.msp, DB = DB.treated, 
                    settings = metaSetting(TSQXLS.GC, "match2DB"), 
                    quick = FALSE)
allSam.matches


###################################################
### code chunk number 11: runGC.Rnw:284-286
###################################################
matchExpSpec(allSamples.msp[[1]][[4]], DB.treated, 
             DB.treated = TRUE, plotIt = TRUE)


###################################################
### code chunk number 12: runGC.Rnw:325-333
###################################################
allSamples.msp.scaled <- lapply(allSamples.msp, treat.DB, 
                                isMSP = FALSE)
allSam.matches <- 
    matchSamples2Samples(allSamples.msp.scaled, 
                         allSamples.msp, 
                         annotations = allSam.matches$annotations, 
                         settings = metaSetting(TSQXLS.GC, "betweenSamples"))
names(allSam.matches)


###################################################
### code chunk number 13: runGC.Rnw:343-344
###################################################
allSam.matches$annotations[[1]]


###################################################
### code chunk number 14: runGC.Rnw:357-360
###################################################
features.df <- getFeatureInfo(stdDB = DB, allMatches = allSam.matches, 
                              sampleList = allSamples.msp)
features.df[, c(1:3, 12:15)]


###################################################
### code chunk number 15: runGC.Rnw:382-387
###################################################
PseudoSpectra <- constructExpPseudoSpectra(allMatches = allSam.matches, 
                                           standardsDB = DB)
ann.df <- getAnnotationMat(exp.msp = allSamples.msp, pspectra = PseudoSpectra, 
                           allMatches = allSam.matches)
ann.df


###################################################
### code chunk number 16: runGC.Rnw:393-397
###################################################
ann.df2 <- sweep(ann.df, 1, sapply(PseudoSpectra, 
                                   function(x) max(x$pspectrum[, 2])), 
                 FUN = "*")
ann.df2


###################################################
### code chunk number 17: runGC.Rnw:421-429
###################################################
library(metaMSdata)
stddir <- system.file("CDF_GC", package = "metaMSdata")
input.file <- list.files(stddir, pattern = "csv", full.names = TRUE)
threeStdsInfo <- readStdInfo(input.file, stddir, sep = ";", dec = ",")
threeStdsInfo[,"stdFile"] <- paste(stddir, 
                                   "GW_130820_12.cdf",
                                   sep = "/")
threeStdsInfo[,c(1:4, 8)]


###################################################
### code chunk number 18: runGC.Rnw:444-446 (eval = FALSE)
###################################################
## data(threeStdsNIST)  ## provides smallDB
## DB <- createSTDdbGC(threeStdsInfo, TSQXLS.GC, extDB = smallDB)


###################################################
### code chunk number 19: runGC.Rnw:455-456
###################################################
data(threeStdsDB)


###################################################
### code chunk number 20: runGC.Rnw:458-459
###################################################
names(DB[[1]])


