## obsolete!

## new version without I/O, using parallel processing of the CDF files
## 30/07: mclapply instead of lapply for parallellization - does this
## work withthe cat statements??

## 1) compare cdfs from input file with cdfs in standards dir
## 2) process all cdfs in parallel
## 3) split xset object, and loop over all elements separately to keep
##    only retention times close to the manually defined times 
## 4) return result

processStandardsGC <- function(stdInfo,
                               instrumentCode)
{
  currentSettings <- metaMSsettings[[instrumentCode]]

  cdfNames <- sort(unique(stdInfo[,"cdf"]))
  xset.l <- peakDetection(cdfNames,
                          currentSettings$xcmsSettings,
                          convert2list = TRUE)
  fn <- names(xset.l)
  
  mclapply(1:length(fn),
           function(i) {
             standard.hits <- which(stdInfo$cdf == cdfNames[i])
             if (length(standard.hits) == 0) {
               warning("No standard compound from table in file ",
                       fn[i], "...skipping\n")
               
               NULL
             } else {
               standard.info <- stdInfo[standard.hits,]
               
               rts <- stdInfo[standard.hits, "RTman"]
               rt.ranges <-
                   cbind(rts - currentSettings$standardSettings$rtdiff,
                         rts + currentSettings$standardSettings$rtdiff) * 60
               
               idx <- which(apply(sapply(1:nrow(rt.ranges),
                                         function(ii)
                                         xset.l[[ i ]]@peaks[,"rt"] >
                                         rt.ranges[ii,1] &
                                         xset.l[[ i ]]@peaks[,"rt"] <
                                         rt.ranges[ii,2]),
                                  1, any))
               if (length(idx) < currentSettings$standardSettings$minfeat) {
                 warning("No peaks with the right retention time found in file ",
                         fn[i], "...skipping\n")
                 
                 NULL
               } else {               
                 xset.l[[i]]@peaks <- xset.l[[i]]@peaks[idx,]
                 
                 xset.g <- cameraGC(xset.l[[i]], currentSettings$cameraSettings)
                 standard.info$date <- as.character(Sys.Date())
                 
                 list(info = standard.info, xset = xset.g)
               }
             }
           }
           )
}
