BiocGenerics:::testPackage("metaMS")
